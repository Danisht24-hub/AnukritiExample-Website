/* Anukriti 2026 – page behaviour (no dependencies) */
(function () {
  'use strict';

  /* ---- Gallery filter ---- */
  var tabs = document.querySelectorAll('.tab');
  var tiles = document.querySelectorAll('#grid .tile');
  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      var f = tab.dataset.filter;
      tabs.forEach(function (t) {
        var on = t === tab;
        t.classList.toggle('is-active', on);
        t.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      tiles.forEach(function (tile) {
        tile.hidden = !(f === 'all' || tile.dataset.type === f);
      });
    });
  });

  /* ---- FAQ accordion (one open at a time) ---- */
  var qs = document.querySelectorAll('.faq__q');
  qs.forEach(function (q) {
    q.addEventListener('click', function () {
      var willOpen = q.getAttribute('aria-expanded') !== 'true';
      qs.forEach(function (other) {
        other.setAttribute('aria-expanded', 'false');
        other.querySelector('i').textContent = '+';
        document.getElementById(other.getAttribute('aria-controls')).hidden = true;
      });
      if (willOpen) {
        q.setAttribute('aria-expanded', 'true');
        q.querySelector('i').textContent = '−';
        document.getElementById(q.getAttribute('aria-controls')).hidden = false;
      }
    });
  });

  /* ---- Registration form ---- */
  var form = document.getElementById('reg-form');
  var err = document.getElementById('reg-error');
  var done = document.getElementById('reg-done');
  var first = document.getElementById('reg-first');

  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = {};
    var ok = true;
    ['name', 'roll', 'email', 'mobile'].forEach(function (k) {
      var input = form.elements[k];
      data[k] = input.value.trim();
      var valid = data[k] !== '' && (k !== 'email' || /^\S+@\S+\.\S+$/.test(data[k]));
      input.classList.toggle('is-bad', !valid);
      if (!valid) ok = false;
    });
    err.hidden = ok;
    if (!ok) return;

    /* TODO: send `data` to your backend / Google Form / Sheet here, e.g.
       fetch('/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) }) */
    first.textContent = data.name.split(' ')[0];
    form.hidden = true;
    done.hidden = false;
  });

})();
